const express = require('express')
require('./db/mongoose')
const Person = require("./models/person")
const app = express()
app.use(express.json())
// Create record person using the person model and save it to the database
// let person = new Person({
//     name: "firstName lastName",
//     age: 19,
//     favoriteFoods: ["Banana", "Cheese"]
// });
// person
//     .save()
//     .then((doc) => {
//         console.log("person is: ")
//         console.log(doc)
//     })
//     .catch((err) => console.error(err))
// // Create Many Records with model.create()
// // Array of People
// let arrayOfPeople = [
//     {
//         name: "Ali",
//         age: 15,
//         favoriteFoods: ["Oranges", "Chicken"]
//     },
//     {
//         name: "Ania",
//         age: 6,
//         favoriteFoods: ["fish","Soupe"],
//     }
// ];
// // Add the array to the database using Person.create 
// Person.create(arrayOfPeople, (err, data) => {
//     if (err) {
//         Person(err);
//     }
//     Person(data);
// })
// // Use Person.find() to Search on Database, all person
// Person
//     .find()
//     .then((doc) => {
//         console.log("Finding persons: ")
//         console.log(doc);
//     })
//     .catch((err) => console.error(err));
// // Use model.findOne() to Return a Single Matching Document from  Database using 
// //the food argument
// Person
//     .findOne({ favoriteFoods: ["fish","Soupe"] })
//     .then((doc) => {
//         console.log("In findOne: ")
//         console.log(doc)
//     })
//     .catch((err) => console.error(err))
// // Use model.findById() to Search Your Database By _id
// Person
//     .findById({ _id: '601c2a103b094ccaa9cded4c' })
//     .then((doc) => {
//         console.log("In findById: ")
//         console.log(doc)
//     })
//     .catch((err) => console.error(err))
// // Perform Classic Updates by Running Find, Edit, then Save
// Person
//     .findById({ _id:'601c2a103b094ccaa9cded4c' })
//     .then((doc) => {
//         doc.favoriteFoods.push("hamburger")
//         doc.save();
//         console.log(doc);
//     })
//     .catch((err) => console.error(err));
// // Perform New Updates on a Document Using model.findOneAndUpdate()
// Person.findOneAndUpdate({age: 15}, {$set:{name:"Not"}}, {new: true}, (err, doc) => {
//     if (err) {
//         console.log("Something wrong when updating data!")
//     }
//     console.log("In findOne and update")
//     console.log(doc)
// })
// Person.remove({ name: 'try' }, { new: true },(err, doc) => {
//     if (err) {
//         console.log("Something wrong when removing data!")
//     }
//     console.log("In remove")
//     console.log(doc)
// })
// Delete One Document Using model.findByIdAndRemove
Person
    .findByIdAndRemove({ _id: '601d1d91296d651cae94bdba' })
    .then((doc) => {
      console.log(doc);
    })
    .catch((err) => console.error(err));
     
//Delete Many Documents with model.remove() with name Ania
Person
   .remove({ name: 'Ania' })
    .then((doc) => {
        console.log(doc);
    })
    .catch((err) => console.error(err));
   // find sort
    Person
    .find().limit(2).sort({age:1}).exec((err,doc)=>{
        if(err){
            console.log("something wrong")}

        console.log("doc")
    })
    Person.find({favoriteFoods: {"$in": ["Banana"]}}).
        limit(1).
        sort({ name: -1 }).
        select({ name: 1, age: 1, favoriteFoods: 1 })
        // select('name age favoriteFoods')
        .exec((err, doc) => {
        if (err) {
            console.log("Something wrong when removing data!")
        }
        console.log("In remove")
        console.log(doc)
})
    
module.exports = app
