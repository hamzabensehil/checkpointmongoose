const mongoose =require("mongoose")
//.env 
//require("dotenv").config
//const MONGODB_URL =`mongodb://${process.env.DATABASE_HOST}:
//${process.env.DATABASE_PORT}/${process.env.DATABASE_NAME}`
mongoose.connect('mongodb://localhost:27017/persondb', {useNewUrlParser: true, useUnifiedTopology: true})
    .then(() => console.log('MongoDB Connected...'))
    .catch((err) => console.log(err))





